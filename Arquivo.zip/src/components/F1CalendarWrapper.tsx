import React, { useEffect, useMemo } from 'react';
import { useF1Calendar } from '../hooks/useF1Calendar';
import { GameSchedule } from './GameSchedule';
import { Card, CardContent } from './ui/card';
import { Loader2, AlertCircle, RefreshCw, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from './ui/button';

interface F1CalendarWrapperProps {
  currentDate: Date;
  onDateSelect: (date: Date) => void;
}

const sports = [
  { id: 'f1', name: 'Fórmula 1', icon: '🏎️' },
];

function toDateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function fromDateKey(key: string) {
  const [year, month, day] = key.split('-').map(Number);
  return new Date(year, month - 1, day);
}

export function F1CalendarWrapper({
  currentDate,
  onDateSelect,
}: F1CalendarWrapperProps) {
  const { events, seasonYear, loading, error, refetch } = useF1Calendar('current');

  const eventDates = useMemo(() => {
    return [...new Set(events.map((event) => event.date))].sort();
  }, [events]);

  useEffect(() => {
    if (!eventDates.length) return;
    if (eventDates.includes(toDateKey(currentDate))) return;
    const today = toDateKey(new Date());
    const next = eventDates.find((date) => date >= today) || eventDates[eventDates.length - 1];
    onDateSelect(fromDateKey(next));
  }, [eventDates, currentDate, onDateSelect]);

  const currentKey = toDateKey(currentDate);
  const currentIndex = eventDates.indexOf(currentKey);
  const dayEvents = events.filter((event) => event.date === currentKey);

  const jumpToEvent = (direction: 1 | -1) => {
    if (!eventDates.length) return;
    if (currentIndex === -1) {
      const fallback = direction === 1
        ? eventDates.find((date) => date > currentKey) || eventDates[eventDates.length - 1]
        : [...eventDates].reverse().find((date) => date < currentKey) || eventDates[0];
      onDateSelect(fromDateKey(fallback));
      return;
    }
    const nextIndex = currentIndex + direction;
    if (nextIndex < 0 || nextIndex >= eventDates.length) return;
    onDateSelect(fromDateKey(eventDates[nextIndex]));
  };

  const goToNextFromToday = () => {
    if (!eventDates.length) return;
    const today = toDateKey(new Date());
    const next = eventDates.find((date) => date >= today) || eventDates[eventDates.length - 1];
    onDateSelect(fromDateKey(next));
  };

  if (loading) {
    return (
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-16">
            <Loader2 className="h-10 w-10 animate-spin text-red-500" />
            <span className="mt-4 text-slate-200">Carregando calendário F1 {seasonYear || 'atual'}...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-slate-900 border-slate-700">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-12">
            <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
            <p className="text-slate-200 mb-4">{error}</p>
            <Button onClick={refetch} variant="outline">
              <RefreshCw className="h-4 w-4 mr-2" />
              Tentar novamente
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 bg-slate-800 rounded-lg border border-slate-500">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
          <span className="text-sm font-semibold text-white">Próxima sessão:</span>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => jumpToEvent(-1)}
              disabled={currentIndex <= 0}
              className="bg-slate-700 border-slate-400 text-white hover:bg-slate-600 disabled:opacity-40"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            <div className="text-center min-w-0 px-2">
              <p className="font-semibold text-sm text-white capitalize">
                {currentDate.toLocaleDateString('pt-BR', {
                  weekday: 'long',
                  day: '2-digit',
                  month: 'long',
                  year: 'numeric',
                })}
              </p>
              <p className="text-xs text-slate-200">
                {dayEvents.length
                  ? dayEvents.map((event) => event.sessionType || event.session).join(' · ')
                  : 'Sem sessão neste dia'}
              </p>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={() => jumpToEvent(1)}
              disabled={currentIndex === -1 || currentIndex >= eventDates.length - 1}
              className="bg-slate-700 border-slate-400 text-white hover:bg-slate-600 disabled:opacity-40"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={goToNextFromToday}
          className="text-xs text-white hover:bg-slate-700"
        >
          Próximo evento
        </Button>
      </div>

      <GameSchedule
        games={events}
        sports={sports}
        currentDate={currentDate}
      />
    </div>
  );
}

export default F1CalendarWrapper;
